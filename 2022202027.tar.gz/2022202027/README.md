Question 1B

The total time complexity of your approach : O(N!)
The total message complexity of your approach : O(N)
The space requirements of your solution : O(N*N)
The performance scaling as you : 
Time required as we go from 1 to 12 process - 1.514,2.344,0.968,0.840,0.918,0.932,0.817,0.796,0.793,0.869,0.812,0.865

Question 2

The total time complexity of your approach : O(N^2)
The total message complexity of your approach : O(N*N)
The space requirements of your solution : O(N*N)
The performance scaling as you : 
Time required as we go from 1 to 12 process - 10.251,14.524,9.587,10.977,11.287,12.554,15.956,18.654,26.549,35.245,40.854,60.257

Question 3

The total time complexity of your approach : O(T*N)
The total message complexity of your approach : O(T*N)
The space requirements of your solution : O(N*M)
The performance scaling as you : 
Time required as we go from 1 to 12 process - 0.081,0.092,0.052,0.041,0.077,0.098,0.0885,0.113,0.153,0.142,0.187,0.214